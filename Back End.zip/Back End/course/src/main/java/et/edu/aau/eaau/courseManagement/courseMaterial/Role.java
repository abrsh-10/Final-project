package et.edu.aau.eaau.courseManagement.courseMaterial;

public enum Role {
    Student,Teacher,Admin
}
