package et.edu.aau.eaau.file;

public enum Type {
    coursematerial,assignment,solution;
}
