package et.edu.aau.eaau.file;

public enum Role {
    Student,Teacher,Admin
}
