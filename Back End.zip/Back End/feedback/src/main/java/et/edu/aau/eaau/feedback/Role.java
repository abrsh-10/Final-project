package et.edu.aau.eaau.feedback;

public enum Role {
    Student,Teacher,Admin
}
