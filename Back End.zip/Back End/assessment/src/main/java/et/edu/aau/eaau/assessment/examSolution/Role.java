package et.edu.aau.eaau.assessment.examSolution;

public enum Role {
    Student,Teacher,Admin
}
