package et.edu.aau.eaau.assessment.exam;

public enum QuestionType {
    True_False,Choose,Fill,Short_Answer
}
