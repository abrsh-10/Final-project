package et.edu.aau.eaau.faq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaqApplicationTests {

	@Test
	void contextLoads() {
	}

}
