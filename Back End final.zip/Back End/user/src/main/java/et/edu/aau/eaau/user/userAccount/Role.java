package et.edu.aau.eaau.user.userAccount;

public enum Role {
    Student,Teacher,Admin
}
