package et.edu.aau.eaau.faq;

public enum Role {
    Student,Teacher
}
